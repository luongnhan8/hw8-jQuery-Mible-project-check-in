let d_table;    // details table
let h_table;    // history table
let s_table;    // summary table
let cash;       // account cash balance
let stock;      // account stock value

// initialize arrays
let tradeArray = [];       // stockObject
let historyArray = [];     // stockObject
let buyArray = [];         // stockObject
let summaryArray = [];     // summaryObject


// global variables
let prevBuyCost_g = 0;
let currGainLoss_g = 0;
let totalGainLoss_g = 0;
let returnPage_g;
let avail_cash_g;


// --------------------- declare stock object ------------------------//
//** constructors */
let stockObject = function (pSymbol, pQuantity, pPrice, pBuySell, pTradeDate, pGainLoss) {
    this.symbol = pSymbol;
    this.quantity = pQuantity;
    this.price = pPrice;
    this.buySell = pBuySell;
    this.tradeDate = pTradeDate;
    this.gainLoss = pGainLoss;
}

// declare net object
let summaryObject = function (pSymbol, pTotalShare, pTotalOrigAmt, pValue) {
    this.symbol = pSymbol;
    this.totalShare = pTotalShare;
    this.totalOrigAmt  = pTotalOrigAmt;
    this.value = pValue;
}
// ----------------- end declare stock object ------------------------//

//** assign document.getelmentbyID   line49 refesh each time 
//** from history , trade , summary page  go to home page */
$(document).ready(function() {
    d_table = document.getElementById("detailsTable");
    h_table = document.getElementById("historyTable");
    s_table = document.getElementById("summaryTable");
    cash = document.getElementById("cash");             //**cash balance from summary page */
    stock = document.getElementById("stock");           //** */
    location.replace(href="#home");   // start in home page


    //** limit and lock the trade date to current buy/sell date */
    // use min value for calendar. Disable older dates.
    let dtToday = new Date();
    let year = dtToday.getFullYear();
    let month = dtToday.getMonth() + 1;
    let day = dtToday.getDate();        
    if (month < 10)     //**from 0-9 --> 00-09 */
        month = '0' + month.toString();
    if (day < 10)       //**from 0-9 --> 00-09 */
        day = '0' + day.toString();
    let minDate = year + '-' + month + '-' + day;   //**format 2021-03-01*/
    $('#tradeDate').attr('min', minDate);       //**'min' calendar property */
});



//** load browser buttons */
document.addEventListener("DOMContentLoaded", function () {    

    // tradeArray.push(new stockObject("CC", 100, 70, "Bought", "2021-03-03", 0));   // 03-13 Bought


    

    //---------------------------- button event ---------------------------------//
//** button enter trade  where to create array?  buy array? trade array?*/
    document.getElementById("buttonTrade").addEventListener("click", function () {
        // read trade info from page
        let symbol = document.getElementById("symbol").value;
        let tradeDate = document.getElementById("tradeDate").value;
        let quantity = parseInt(document.getElementById("quantity").value);
        let price = parseInt(document.getElementById("price").value);
        let buySell = document.getElementById("select-buysell").value;
        let boughtSold = (buySell === "buy") ? "Bought" : "Sold";   //**for display on history/detail page */
        // let avail_cash;           //** declare var for read in from cash balance */
        tradeArray = [];          // 03-13

        currGainLoss_g = 0;         //**global declare */
        let cost = quantity * price;

        //**push up to trade array */
        // save into tradeArray
        tradeArray.push(new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g));

        //** cash.value = line48  document.getElementById("cash").value (read the ash balance from summary page) */
        // if buying, check enough cash
        // avail_cash = parseInt(cash.value);   //**from summary page */


        // if selling, search how many shares are available
        let idx = FindSymbol(symbol);       //** -1 symbol not found in summary page */
        avail_quantity = (idx > -1) ? summaryArray[idx].totalShare : 0;

        //**
        //**  if (idx > -1) {
        //**  avail_quantity = summaryArray[idx].totalShare;
        //**  }
        //**  else{
        //**  avail_quantity = 0;
        //**  }
        //** */


        //**not relate to app.js but this is the condition for buy/sell buton */
        // checking buy/sell eligibility
        if ((buySell === "buy") && (cost <= avail_cash_g) ||
            (buySell === "sell") && (quantity <= avail_quantity)) {

            if (buySell === "buy") {
                
                //***buy array suck in whatever buy event */
                buyArray.push(new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g));   // 03-13
                
                let newBuy = new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g);     // 03-13              
                addNewBuy(newBuy);

                buyArray.sort(bySymbol);
                // update available cash
                avail_cash_g -= cost;
                cash.value = avail_cash_g;
            } else {
                //** sell event then update changes to buy array */
                let update_pos = UpdateGainLoss(symbol, quantity, price);  // generate gianLoss from use buyArray
                // update buyArray on the server

                // update currGainLoss to totalGainLoss
                tradeArray[0].gainLoss = currGainLoss_g;
                totalGainLoss_g += currGainLoss_g;

                // update available cash
                avail_cash_g += cost;  // gainLoss included. prevBuyCost not included!
                cash.value = avail_cash_g;               
            }
            // need to post avail_cash_g to server as serverAvailCash !!!
            postCashToServer();
            
            // update historyTable
            //**history array push every single time */
            historyArray.push(new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g));  // 03-13
                
            let newHistory = new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g);   
            addNewHistory(newHistory);

            //FillArrayFromServer();
            //**built to table I am not care */
            AddToHistoryPage();

            // update gainLoss in tradeArray to build in detailsTable
            ShowDetailsPage();            //enter trade button/summary page then go here

            BuildSummaryArray();          // use tradeArray
            BuildSummaryTable();
    
            // reset variables  03-13
            tradeArray = [];
            currGainLoss_g = 0;
            prevBuyCost_g = 0;

            // go to the next page
            //***this return meaning when tade button go in detail page then button return back to trade page etc.. */
            returnPage_g = "trade";
            // alert("before jumping to details page");
            document.location.href = "index.html#details";      //out put jump to detail page
        } else {
            alert("Not enought cash for buying or no available stock to sell!");
        }
        // reset variables
        // tradeArray = [];
        // currGainLoss_g = 0;
        // prevBuyCost_g = 0;

        // clear trade page data
        document.getElementById("symbol").value = "";
        document.getElementById("quantity").value = "";
        document.getElementById("price").value = "";
    });


    //---------------------- clear button event ---------------------------------//
    document.getElementById("buttonClear").addEventListener("click", function () {
        document.getElementById("symbol").value = "";
        document.getElementById("quantity").value = "";
        document.getElementById("price").value = "";
        document.getElementById("select-buysell").value = "";
    });


    //--------------------- RETURN button event -----------------------------//

    document.getElementById("return").addEventListener("click", function () {
        if (returnPage_g === "trade") {
            returnPage_g = "";
            document.location.href = "index.html#trade";    // go back to trade page
        } else if (returnPage_g === "summary") {
            returnPage_g = "";
            document.location.href = "index.html#summary";  // go back to summary page
        } else {
            document.location.href = "index.html#history";  // go back to movie list 
        }       
    });

    //----------------------- pagebeforeshow -------------------------------//

    $(document).on("pagebeforeshow", "#history", function (event) {   // have to use jQuery 
        FillHistoryArrayFromServer();
    });

    $(document).on("pagebeforeshow", "#summary", function (event) {   // have to use jQuery 
        FillSummaryArrayFromServer();
        // need to download avail_cash from server
        FillAvailCashFromServer();
    });

    $(document).on("pagebeforeshow", "#trade", function (event) {   // have to use jQuery 
        FillBuyArrayFromServer();
    });

});

//----------------------- end button events ---------------------------------//







// ------------------- calculate gain loss ---------------------------------//
// calculate gain loss using buyArray. Selling uses first-in-first-out method.
// Search buyArray[] to see matched symbol. Check shares to see enough shares to sell.
// If not, search next line until accumulating enough shares to sell.


//**ellen need to download buy array then do calculation in updategainloss function then finish 
//**calculation then go upload to buyarray */ 
function UpdateGainLoss(symbol, sellQuantity, sellPrice) {
    currGainLoss_g = 0;   // global variable
    let index = -1;       // 03-13
    // searching for symbol in buyArray to calculate gain loss for current trade
    for (let i = 0; i < buyArray.length; i++) {
        if (symbol === buyArray[i].symbol) {
            // read previous buy info
            let prevBuyQuantity = parseInt(buyArray[i].quantity); 
            let prevBuyPrice = parseInt(buyArray[i].price);   
            currGainLoss_g = parseInt(buyArray[i].gainLoss);
            
            // read each buyArray[i] to accumulate enough quantity to sell
            let accumQty = prevBuyQuantity;
            let accumBuyCost = 0;
            let accumGainLoss = 0;
            let sellQty_remain = sellQuantity;
            while (accumQty < sellQuantity) {   // enough quantity to sell ?
                // not enough quantity to sell
                accumBuyCost += buyArray[i].quantity * buyArray[i].price;
                accumGainLoss += buyArray[i].quantity * (sellPrice - buyArray[i].price);
                sellQty_remain -= buyArray[i].quantity;
                buyArray.splice(buyArray[i], 1);     // remove buyArray[i]
                accumQty += buyArray[i].quantity;    // add next quantity
            }  
            // enough quantity to sell
            accumBuyCost += sellQty_remain * buyArray[i].price;
            accumGainLoss += sellQty_remain * (sellPrice - buyArray[i].price);
            newQuantity = accumQty - sellQuantity;
            buyArray[i].quantity = newQuantity;
            buyArray[i].gainLoss = accumGainLoss; 
            currGainLoss_g = accumGainLoss;
            prevBuyCost_g = accumBuyCost;

            // need to update buyArray on server !!!!!

            // remove buyArray after selling all
            if (sellQuantity === accumQty){
                buyArray.splice(buyArray[i], 1);
            }
            index = i;   // 03-13
            break;
        }
    }
    return index;   // 03-13

 //** ellen need to uploaded back to buy array after sell only event */   
}  // UpdateGainLoss()
//** here is the end of updatgainlost calculation */

// ------------------- Building tables --------------------------------//

function AddToHistoryPage() {    // should be renamed to buildHistoryTable() 03-13
    let rowCount = h_table.rows.length; 
    let rowCount_dbg = historyArray.length;  // DEBUG 03-13

    while (rowCount > 1 ) {
        h_table.deleteRow(1);
        rowCount = h_table.rows.length;
    }

    rowCount = 1;
    for (let i=0; i < historyArray.length; i++) {  // 03-13
        let newRow = h_table.insertRow(rowCount);
        let cell1 = newRow.insertCell(0);
        let cell2 = newRow.insertCell(1);
        let cell3 = newRow.insertCell(2);
        let cell4 = newRow.insertCell(3);
        let cell5 = newRow.insertCell(4);
        let cell6 = newRow.insertCell(5);
        let cell7 = newRow.insertCell(6);

        cell1.innerHTML = historyArray[i].symbol;
        cell2.innerHTML = historyArray[i].buySell;
        cell3.innerHTML = historyArray[i].quantity
        cell4.innerHTML = historyArray[i].price;
        cell5.innerHTML = historyArray[i].quantity * historyArray[i].price;
        cell6.innerHTML = historyArray[i].tradeDate;
        cell7.innerHTML = historyArray[i].gainLoss;
        rowCount ++;
    }
}  // AddToHistoryPage() 


// show details page. This page uses currTradeArry[] to build table.
// tradeArray[] is also used in the summary page to get to the details page
function ShowDetailsPage() {   
    let rowCount = d_table.rows.length;
    // clearing the detailsTable except the 1st row
    while (rowCount > 1 ) {
        d_table.deleteRow(1);
        rowCount = d_table.rows.length;
    }

    let row = 1;
    for (let i=0; i < tradeArray.length; i++) {
        let newRow = d_table.insertRow(row);        //make row of table in detail page
        let cell1 = newRow.insertCell(0);           //make column of table in detail page
        let cell2 = newRow.insertCell(1);
        let cell3 = newRow.insertCell(2);
        let cell4 = newRow.insertCell(3);
        let cell5 = newRow.insertCell(4);
        let cell6 = newRow.insertCell(5);
        let cell7 = newRow.insertCell(6);

        cell1.innerHTML = tradeArray[i].symbol;
        cell2.innerHTML = tradeArray[i].buySell;
        cell3.innerHTML = tradeArray[i].quantity
        cell4.innerHTML = tradeArray[i].price;
        cell5.innerHTML = tradeArray[i].quantity * tradeArray[0].price;
        cell6.innerHTML = tradeArray[i].tradeDate;
        cell7.innerHTML = tradeArray[i].gainLoss;
        row ++;
    }
}  // ShowDetailsPage() 



// build summaryTable (derived from tradeArray)
function BuildSummaryArray() {
    // save new stock into clone
    let symbol = tradeArray[0].symbol;
    let quantity = tradeArray[0].quantity;
    let price = parseInt(tradeArray[0].price);
    let cost = quantity * price;
    let value = tradeArray[0].gainLoss;
    let buySell = tradeArray[0].buySell;
    
//**before go in the step below = summary array then ellen need to download summary array,  */
//**the do the if else below then the results need to upload to summary array=new value in summary array */
//**line 317 (if...<1 )is for check is true upload push to summary array */
    if (summaryArray.length < 1) {    // save if array is empty
        summaryArray.push(summaryObject(symbol, quantity, cost, value));  // 03-13

        let newSummary = new summaryObject(symbol, quantity, cost, value);
        addNewSummary(newSummary);

//** need to upload push on here */
//** (else...)check else is true then work step below */
    } else {    
        // search symbol in summaryArray
        let idx = FindSymbol(symbol);
//** if is true means else is false means NOT find the symbol */
        if (idx == -1) {
            // not in array, save
            //summaryArray.push(
             let newSummary = new summaryObject(symbol, quantity, cost, value);

             addNewSummary(newSummary);

    //** need to upload push on this summmaryarry form here here */

        } else {
    //** if (else) here is true means symbol is found then go to update by upload all changes to
    //** line 347 348 349 these 3 lines are the results from line 335 336 337 338 339
    //** then update these changes results to summaryarray and push this summmary array=new to server*/
            // found symbol in summaryArray, update quantity and value
            let sign = (buySell === "Bought") ? 1 : -1;   //** here elle nstill holding old down load summary array */
            let newQuantity = summaryArray[idx].totalShare + (sign * quantity);  //**updat changes in quantity
            let prevGain = summaryArray[idx].value; //**update change in gain/lost */
            let newCost;
            if (buySell === "Bought") {
                // when buying, add the current buy cost to the current cost
                newCost = summaryArray[idx].totalOrigAmt + (sign * cost);  // =.cost-quantity*buyPrice
            } else {
                // when selling, subtract the previous cost (for the sell quantity) from the current cost
                newCost = summaryArray[idx].totalOrigAmt - prevBuyCost_g;
            }

            summaryArray[idx].totalShare = newQuantity;
            summaryArray[idx].totalOrigAmt = newCost;
            summaryArray[idx].value = prevGain + currGainLoss_g;
        }
        //**ellen have to update changes result to old download summary to new summary array then
        //**upload push to server only push*/ */
    }
}  // BuildSummeryArray()


function BuildSummaryTable() {   
    let rowCount = s_table.rows.length;
    let rowCount_dbg = summaryArray.length;   // DEBUG 03-13
 
    // remove all data rows from summary table (except the header)
    while (rowCount > 1 ) {
        s_table.deleteRow(1);
        rowCount = s_table.rows.length;
    }
    // sort summaryArray by symbol
    summaryArray.sort(bySymbol);
    sid = 0;
  
    // add rows to table
    let stock_value = 0;
    let cost = 0;
    let row = 1;
    for (let i = 0; i < summaryArray.length; i ++) {

        // add a new row then add id and onclick funtion
        let newRow = s_table.insertRow(row);       
        newRow.setAttribute("id", i);
        newRow.addEventListener("click", function() {
            FnIndex(i);
        })

        let cell1 = newRow.insertCell(0);   // symbol
        let cell2 = newRow.insertCell(1);   // quantity
        let cell3 = newRow.insertCell(2);   // cost
        let cell4 = newRow.insertCell(3);   // value

        // accumulate total cost
        cost  = summaryArray[i].totalOrigAmt;
        stock_value += cost;

        cell1.innerHTML = summaryArray[i].symbol;
        cell2.innerHTML = summaryArray[i].totalShare;
        cell3.innerHTML = summaryArray[i].totalOrigAmt;
        cell4.innerHTML = summaryArray[i].value;
        row ++;
    };

    // update total stock value in summary page
    stock.value = stock_value;

}   // BuildSummaryTable()

// -------------------- end Building tables --------------------------------//





// A link in the summary table was clicked, symbol passed to here.
// Copy historyArray[] to currTradeArry[]
// Search thru historyArray[] for symbol.
// Keep tradeArray[]for same symbol, remove all other symbols. 

function FnIndex(num) {
    let localSymbol = summaryArray[num].symbol;
 
    // copy historyArray[] to tradeArray[]
    tradeArray = [];
    let cloneReturn = Object.assign(tradeArray, historyArray);      //*****? */

    // search historyArray for the same symbol to save in tradeArray[]
    let subtract = 0;
    for (let i=0; i < historyArray.length; i++) {
        if (historyArray[i].symbol !== localSymbol) {
            // remove from currTradeAccry if not same symbol
            tradeArray.splice(i-subtract, 1);
            subtract ++;
        }
    }
    ShowDetailsPage();
    returnPage_g = "summary";
    document.location.href = "index.html#details";  // jumpp to details page
}

//**for summary page due to (history page random symbol) (-1, 0 , 1) */
// sort the array
function bySymbol(a, b) {
    let comparison = 0;
    if (a.symbol > b.symbol) {
      comparison = 1;
    } else if (a.symbol < b.symbol) {
      comparison = -1;
    }
    return comparison;
}

//**function to find/searh symbol from sauumary page */
// search summaryArray for symbol
function FindSymbol(symbol) {
    for (let i = 0; i < summaryArray.length; i++) {
        if (summaryArray[i].symbol === symbol)
        return i;
    }
    return -1;          //**less than 0 is -1=not matched*/
}


//************************************************************************** */
//**server stuff  */
//************************************************************************** */


//---------------- historyArray: download, POST and PUT ---------------------//

//fetch object to server array
//add a new function at very bottom of the client's index.js
//This uses the new HTML V6 "Fetch" feature to ask the server for data
//**history
function FillHistoryArrayFromServer(){
    // using fetch call to communicate with node server to get all data
    fetch('/history')
    .then(function (theResponsePromise) {  // wait for reply.  Note this one uses a normal function, not an => function
        return theResponsePromise.json();
    })
    .then(function (serverHistoryData) { // now wait for the 2nd promise, which is when data has finished being returned to client
    console.log(serverHistoryData);
    historyArray.length = 0;  // clear array
    historyArray = serverHistoryData;   // use our server json data which matches our objects in the array perfectly
    // createList();  // placing this here will make it wait for data from server to be complete before re-doing the list
    AddToHistoryPage();   // 03-13
    })
    .catch(function (err) {
     console.log(err);
    });
};


// using fetch to push an object up to server update changes to server
function addNewHistory(newHistory){
    // the required post body data is our hisoty object passed into this function
        
        // create request object
        const request = new Request('/addHistory', {
            method: 'POST',
            body: JSON.stringify(newHistory),
            headers: new Headers({
                'Content-Type': 'application/json'
            })
        });
        
      // use that request object we just created for our fetch() call
      fetch(request)
      // wait for frist server promise response of "200" success 
      // (can name these returned promise objects anything you like)
         .then(function (theResponsePromise) {    // the .json sets up 2nd promise
          return theResponsePromise.json()  })
       // now wait for the 2nd promise, which is when data has finished being returned to client
          .then(function (theResponsePromiseJson) { 
            console.log(theResponsePromiseJson.toString()) 
            //,document.location.href = "#hitory" 
            })
      // the client console log will write out the message I added to the Repsonse on the server
      .catch(function (err) {
          console.log(err);
      });   
}; // end of addhistory  03-13



//---------------- buyArray: download, POST and PUT --------------------------//

function FillBuyArrayFromServer(){    // 03-13
    fetch('/buy')
        .then(function (theResponsePromise) {    // the .json sets up 2nd promise
          return theResponsePromise.json();  })
        .then(function (serverBuyData) { 
            console.log(serverBuyData);
            buyArray.length = 0; 
            buyArray = serverBuyData;  
        })
        .catch(function (err) {
          console.log(err);
    }); 
};  //  03-13

//** enter trade button start */
// using fetch to push an object up to server update changes to server
function addNewBuy(newBuy){
    // the required post body data is our hisoty object passed into this function
        
        // create request object
        const request = new Request('/addBuy', {
            method: 'POST',
            body: JSON.stringify(newBuy),
            headers: new Headers({
                'Content-Type': 'application/json'
            })
        });

    fetch(request)
        .then(function (theResponsePromise) {    // the .json sets up 2nd promise
          return theResponsePromise.json()  })
        .then(function (theResponsePromiseJson) { 
            console.log(theResponsePromiseJson.toString());
        })
        .catch(function (err) {
            console.log(err);
    });
}; // end of addBuy



//---------------- summaryArray: download, POST and PUT --------------------------//

//**summary
function FillSummaryArrayFromServer(){
    // using fetch call to communicate with node server to get all data
    fetch('/summary')
        .then(function (theResponsePromise) {  // wait for reply.  Note this one uses a normal function, not an => function
            return theResponsePromise.json();
        })
        .then(function (serverSummaryData) { // now wait for the 2nd promise, which is when data has finished being returned to client
            console.log(serverSummaryData);
            summaryArray.length = 0;  // clear array   03-13
            summaryArray = serverSummaryData;   // use our server json data which matches our objects in the array perfectly
            BuildSummaryTable();   // 03-13
        })
        .catch(function (err) {
            console.log(err);
        });
};
    // using fetch to push an object up to server update changes to server  serverSummaryArray
function addNewSummary(newSummary){
    // the required post body data is our Summary object passed into this function
        
        // create request object
        const request = new Request('/addSummary', {
            method: 'POST',
            body: JSON.stringify(newSummary),
            headers: new Headers({
                'Content-Type': 'application/json'
            })
        });

      // use that request object we just created for our fetch() call
      fetch(request)
      // wait for frist server promise response of "200" success 
      // (can name these returned promise objects anything you like)
         .then(function (theResponsePromise) {    // the .json sets up 2nd promise
          return theResponsePromise.json()  })
       // now wait for the 2nd promise, which is when data has finished being returned to client
          .then(function (theResponsePromiseJson) { 
            console.log(theResponsePromiseJson.toString()) 
            //,document.location.href = "#hitory" 
            })
      // the client console log will write out the message I added to the Repsonse on the server
      .catch(function (err) {
          console.log(err);
      });
}; // end of addSummary    03-13
    
// using fetch to push an object up to server
function modifySummary(newSummary){
    // movie constructor function gave this a new ID, set it back to what it was
    newSummary.ID= document.getElementById("summary").innerHTML;
    // create fetch request object
 
    // a put requires both a URL passed value and an object in the body
    // that way you could tell the server, find the object with this ID  passed in the URL
    // and replace it with an object that is in the body that MIGHT have an updated and different ID.
    const request = new Request('/modifySummary/' + newSummary.ID, {
        method: 'PUT',
        body: JSON.stringify(newSummary),
        headers: new Headers({
            'Content-Type': 'application/json'
        })
    });
        
    // use that request object we just created for our fetch() call
    fetch(request)
    // wait for frist server promise response of "200" success 
        .then(function (theResponsePromise) {    // the .json sets up 2nd promise
            return theResponsePromise.json()  })
        // now wait for the 2nd promise, which is when data has finished being returned to client
        .then(function (theResponsePromiseJson) { 
            console.log(theResponsePromiseJson.toString())
            //document.location.href = "#ListAll" 
        })
        // the client console log will write out the message I added to the Repsonse on the server
        .catch(function (err) {
            console.log(err);
    });
}; // end of modifyMovie



//------------------ avail_cash: download, POST and PUT --------------------------//

function FillAvailCashFromServer(){    // 03-13
    fetch('/cash')
        .then(function (theResponsePromise) {
          return theResponsePromise.json();  })
        .then(function (serverAvailCash) { 
            console.log(serverAvailCash);
            avail_cash_g = serverAvailCash;
            cash.value = avail_cash_g;   // display cash in summary page
        })
        .catch(function (err) {
            console.log(err);
    });       
};  //  03-13



function postCashToServer(){
    const request = new Request('/cash', {
    method: 'PUT',
    body: JSON.stringify({"CASH": avail_cash_g}),
    headers: new Headers({
    'Content-Type': 'application/json'
    })
    });
    

// function postCashToServer(){
//     const request = new Request('/cash', {
//         method: 'POST',
//         body: JSON.stringify(avail_cash_g),
//         headers: new Headers({
//             'Content-Type': 'application/json'
//         })
//     });

//     fetch(request)
//         .then(function (theResponsePromise) {
//             return theResponsePromise.json()  })
//         .then(function (theResponsePromiseJson) { 
//             console.log(theResponsePromiseJson.toString()) 
//         })
//         .catch(function (err) {
//             console.log(err);
//     });
}

// using fetch to push an object up to server
function modifyBuyArray(){
    // movie constructor function gave this a new ID, set it back to what it was
    // newSummary.ID= document.getElementById("summary").innerHTML;
    // create fetch request object
 
    // a put requires both a URL passed value and an object in the body
    // that way you could tell the server, find the object with this ID  passed in the URL
    // and replace it with an object that is in the body that MIGHT have an updated and different ID.
    // const request = new Request('/modifySummary/' + newSummary.ID, {
    const request = new Request('/buy/', {
        method: 'PUT',
        body: JSON.stringify(buyArray),
        headers: new Headers({
            'Content-Type': 'application/json'
        })
    });
        
    // use that request object we just created for our fetch() call
    fetch(request)
    // wait for frist server promise response of "200" success 
        .then(function (theResponsePromise) {    // the .json sets up 2nd promise
            return theResponsePromise.json()  })
        // now wait for the 2nd promise, which is when data has finished being returned to client
        .then(function (theResponsePromiseJson) { 
            console.log(theResponsePromiseJson.toString())
            //document.location.href = "#ListAll" 
        })
        // the client console log will write out the message I added to the Repsonse on the server
        .catch(function (err) {
            console.log(err);
    });
}; // end of modifyMovie

