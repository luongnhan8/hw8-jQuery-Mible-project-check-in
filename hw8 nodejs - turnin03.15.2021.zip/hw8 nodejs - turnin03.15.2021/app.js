var express = require('express');
var path = require('path');

//leaving in the bodyParser in case we ever send up form data and need to get data out of form
var bodyParser = require('body-parser');


var app = express();

// view engine setup
app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static('public'));

//**start server arrays from java index .js  */

let serverBuyArray = [];      
let serverHistoryArray = [];      
let serverSummaryArray = [];   

//**constructors */
// --------------------- define stock object ------------------------//

let stockObject = function (pSymbol, pQuantity, pPrice, pBuySell, pTradeDate, pGainLoss) {
    this.symbol = pSymbol;
    this.quantity = pQuantity;
    this.price = pPrice;
    this.buySell = pBuySell;
    this.tradeDate = pTradeDate;
    this.gainLoss = pGainLoss;

}

// define net object
let summaryObject = function (pSymbol, pTotalShare, pTotalOrigAmt, pValue) {
    this.symbol = pSymbol;
    this.totalShare = pTotalShare;
    this.totalOrigAmt  = pTotalOrigAmt;
    this.value = pValue;
}

// ----------------- end declare stock object ------------------------//

//**push up to array */
// serverHistoryArray.push(new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g));       
// sercerBuyArray.push(new stockObject(symbol, quantity, price, boughtSold, tradeDate, currGainLoss_g));
// serverSummaryArray.push(new summaryObject(symbol, quantity, cost, value));

// ** pre-set array data*/

serverHistoryArray.push(new stockObject("BB", 100, 60, "Bought", "2021-02-02", 0));  // 03-13
serverHistoryArray.push(new stockObject("AA", 100, 50, "Bought", "2021-01-01", 0));  // 03-13
serverHistoryArray.push(new stockObject("CC", 100, 70, "Bought", "2021-03-03", 0));  // 03-13

serverBuyArray.push(new stockObject("BB", 100, 60, "Bought", "2021-02-02", 0));
serverBuyArray.push(new stockObject("AA", 100, 50, "Bought", "2021-01-01", 0));
serverBuyArray.push(new stockObject("CC", 100, 70, "Bought", "2021-03-03", 0));

serverSummaryArray.push(new summaryObject("BB", 100, 6000, 0));
serverSummaryArray.push(new summaryObject("AA", 100, 5000, 0));
serverSummaryArray.push(new summaryObject("CC", 100, 7000, 0));

let serverAvailCash = 82000;   // 03-13  82000=100000-5000-6000-7000


// just one "site" with 2 pages, / and about

// use res.render to load up an ejs view file
// index page 

app.get('/', function(req, res){
    res.sendFile(__dirname + '/index.html');
});

//***********start get; post; put for history, summary, buy, avil_cash********/

/**===================GET buyarray in trade page===================*/
app.get('/buy', function(req, res) {
    res.json(serverBuyArray);
});

/**=================POST to addBuy=================================*/
app.post('/addBuy', function(req, res) {
    console.log(req.body);
    serverBuyArray.push(req.body);
    // set the res(ponse) object's status propery to a 200 code, which means success
    res.status(200).send(JSON.stringify('success'));
  });

//**===============Put to addbuy=================================*/
app.put('/modifyBuy/:id', (req, res) => {
    let id = req.params.id;
    let buyObject = req.body;
    //console.log(id);
    //console.log(movieObject);
    for (var i = 0; i < serverBuyArray.length; i++) {
        if (serverBuyArray[i].ID == id) {
            serverBuyArray[i] = buyObject;  // remove 1 element at loc i
            res.send('success');
        }
    }
    res.status(404);  // if not found
});

//***=========end of get post put for buyArray=========*/


/**===========GET historyarray in history page===============*/
app.get('/history', function(req, res) {
    res.json(serverHistoryArray);
});
     
   
//**============POST to addHistory==========================*/
app.post('/addHistory', function(req, res) {
    console.log(req.body);
    serverHistoryArray.push(req.body);
    // set the res(ponse) object's status propery to a 200 code, which means success
    res.status(200).send(JSON.stringify('success'));
  });

//***=========end of get post for historyArray=========*/

  
//**===========GET summaryarray in summary page========== */
app.get('/summary', function(req, res) {
    res.json(serverSummaryArray);
});


//**==========POST to addSummary======================== */
app.post('/addSummary', function(req, res) {
    console.log(req.body);
    serverSummaryArray.push(req.body);
    // set the res(ponse) object's status propery to a 200 code, which means success
    res.status(200).send(JSON.stringify('success'));
});

//**===========Put to summary page===================== */
app.put('/modifySummary/:id', (req, res) => {
    let id = req.params.id;
    let summaryObject = req.body;
    //console.log(id);
    //console.log(movieObject);
    for (var i = 0; i < serverSaummaryArray.length; i++) {
        if (serverSummaryArray[i].ID == id) {
            serverSummaryArray[i] = summaryObject;  // remove 1 element at loc i
            res.send('success');
        }
    }
    res.status(404);  // if not found
});

//***=========end of get post put for summaryArray=========*/



//**========= get avail_cash not array to server============*/
app.get('/cash', function(req, res) {
    res.json(serverAvailCash);
});

//**============POST to add available cash==========================*/
app.post('/addcash', function(req, res) {
    console.log(req.body);
    serverAvailCash.push(req.body);
    // set the res(ponse) object's status propery to a 200 code, which means success
    res.status(200).send(JSON.stringify('success'));
  });

//***=========end of get post for availableArray=========*/

//**===========Put to available cash page===================== */

app.put('/cash', function(req, res) {
    let cash = req.body;
    console.log(cash);
    serverAvailCash = cash.CASH;
    res.json(serverAvailCash);
    });


// app.put('/modifycash/:id', (req, res) => {
//     let id = req.params.id;
//     let cashObject = req.body;
//     //console.log(id);
//     //console.log(movieObject);
//     for (var i = 0; i < serverAvailCash.length; i++) {
//         if (serverAvailCash.ID == id) {
//             serverAvailCash = cashObject;  // remove 1 element at loc i
//             res.send('success');
//         // }
//     }
//     res.status(404);  // if not found
// });

//***=========end of get put for availableArray=========*/

/**end of add array to server */




// error page 
app.get('/error', function(req, res) {
    // should get real data from some real operation, but instead ...
    let message = "some text from someplace";
    let errorObject ={
        status: "this is real bad",
        stack: "somebody called #$% somebody who called somebody <awful>"
    };
    res.render('pages/error', {  // pass the data to the page renderer
        message: message,
        error: errorObject
    });
});



app.listen(3000);  // not setting port number in www.bin, simple to do here
console.log('3000 is the magic port');

module.exports = app;
